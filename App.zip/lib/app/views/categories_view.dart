import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/category_controller.dart';
import '../core/constants.dart';
import '../core/utils.dart';
import '../data/models/category.dart';

class CategoriesView extends StatelessWidget {
  const CategoriesView({super.key});

  void _add(String type) {
    final cc = Get.find<CategoryController>();
    final name = TextEditingController();
    String icon = 'other';
    int color = kPalette[4];

    Get.dialog(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text(type == 'expense' ? 'new_expense_cat'.tr : 'new_income_cat'.tr),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(controller: name, decoration: InputDecoration(labelText: 'cat_name'.tr)),
              const SizedBox(height: 16),
              Text('icon'.tr),
              const SizedBox(height: 8),
              Wrap(spacing: 6, runSpacing: 6, children: [
                for (final e in kIcons.entries)
                  InkWell(
                    onTap: () => setState(() => icon = e.key),
                    child: CircleAvatar(
                      radius: 18,
                      backgroundColor: icon == e.key ? Color(color) : Colors.grey.withOpacity(0.2),
                      child: Icon(e.value, size: 18, color: icon == e.key ? Colors.white : null),
                    ),
                  ),
              ]),
              const SizedBox(height: 16),
              Text('color'.tr),
              const SizedBox(height: 8),
              Wrap(spacing: 6, runSpacing: 6, children: [
                for (final c in kPalette)
                  InkWell(
                    onTap: () => setState(() => color = c),
                    child: CircleAvatar(
                      radius: 14,
                      backgroundColor: Color(c),
                      child: color == c ? const Icon(Icons.check, size: 16, color: Colors.white) : null,
                    ),
                  ),
              ]),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: Text('cancel'.tr)),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) {
                toast('notice'.tr, 'enter_cat_name'.tr, error: true);
                return;
              }
              await cc.add(CategoryModel(name: name.text.trim(), type: type, icon: icon, color: color));
              Get.back();
            },
            child: Text('add'.tr),
          ),
        ],
      ),
    ));
  }

  Widget _list(List<CategoryModel> items, CategoryController cc) => ListView(
        padding: const EdgeInsets.only(bottom: 96),
        children: [
          for (final c in items)
            ListTile(
              leading: CircleAvatar(
                backgroundColor: Color(c.color).withOpacity(0.15),
                child: Icon(iconOf(c.icon), color: Color(c.color)),
              ),
              title: Text(c.name),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  if (await confirm('delete_category'.tr, 'delete_cat_msg'.trParams({'n': c.name}))) await cc.remove(c);
                },
              ),
            ),
        ],
      );

  @override
  Widget build(BuildContext context) {
    final cc = Get.find<CategoryController>();
    return DefaultTabController(
      length: 2,
      child: Builder(
        builder: (context) => Scaffold(
          appBar: AppBar(
            title: Text('categories_title'.tr),
            bottom: TabBar(tabs: [Tab(text: 'expenses_plural'.tr), Tab(text: 'incomes_plural'.tr)]),
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: () => _add(DefaultTabController.of(context).index == 0 ? 'expense' : 'income'),
            child: const Icon(Icons.add),
          ),
          body: Obx(() => TabBarView(children: [_list(cc.expenseCats, cc), _list(cc.incomeCats, cc)])),
        ),
      ),
    );
  }
}
