import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../core/constants.dart';
import '../core/utils.dart';

class UsersView extends StatelessWidget {
  const UsersView({super.key});

  void _add() {
    final app = Get.find<AppController>();
    final name = TextEditingController();
    String cur = kCurrencies.contains(app.user.value.currency) ? app.user.value.currency : kCurrencies.first;

    Get.dialog(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text('new_user'.tr),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, autofocus: true, decoration: InputDecoration(labelText: 'user_name'.tr)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: cur,
              decoration: InputDecoration(labelText: 'currency'.tr),
              items: [for (final c in kCurrencies) DropdownMenuItem(value: c, child: Text(c))],
              onChanged: (v) => setState(() => cur = v ?? cur),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: Text('cancel'.tr)),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) {
                toast('notice'.tr, 'enter_name'.tr, error: true);
                return;
              }
              await app.addUser(name.text.trim(), cur);
              Get.back();
              toast('users_title'.tr, 'user_added'.tr);
            },
            child: Text('add'.tr),
          ),
        ],
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final app = Get.find<AppController>();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text('users_title'.tr)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.person_add_alt_1),
        label: Text('new_user'.tr),
      ),
      body: Obx(() => ListView(
            padding: const EdgeInsets.only(bottom: 96),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Text('users_hint'.tr, style: Theme.of(context).textTheme.bodySmall),
              ),
              for (final u in app.users)
                ListTile(
                  selected: u.id == app.user.value.id,
                  leading: CircleAvatar(
                    backgroundColor: u.id == app.user.value.id ? cs.primary : cs.surfaceContainerHighest,
                    foregroundColor: u.id == app.user.value.id ? cs.onPrimary : cs.onSurface,
                    child: Text(u.name.isEmpty ? '?' : u.name.characters.first.toUpperCase()),
                  ),
                  title: Text(u.name),
                  subtitle: Text(u.id == app.user.value.id ? '${'current'.tr} • ${u.currency}' : u.currency),
                  onTap: () async {
                    if (u.id != app.user.value.id) {
                      await app.switchUser(u.id!);
                      toast('users_title'.tr, 'switched_to'.trParams({'name': u.name}));
                    }
                  },
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () async {
                      if (app.users.length <= 1) {
                        toast('notice'.tr, 'last_user_msg'.tr, error: true);
                        return;
                      }
                      if (await confirm('delete_user'.tr, 'delete_user_msg'.trParams({'n': u.name}))) {
                        await app.removeUser(u);
                      }
                    },
                  ),
                ),
            ],
          )),
    );
  }
}
