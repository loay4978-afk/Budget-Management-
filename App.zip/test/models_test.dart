import 'package:flutter_test/flutter_test.dart';
import 'package:masrofi/app/core/utils.dart';
import 'package:masrofi/app/data/models/budget.dart';
import 'package:masrofi/app/data/models/transaction.dart';
import 'package:masrofi/app/data/models/transfer.dart';

void main() {
  test('Budget ratio and remaining', () {
    final b = const Budget(categoryId: 1, amount: 200).withSpent(150);
    expect(b.ratio, 0.75);
    expect(b.remaining, 50);
    expect(const Budget(categoryId: 1, amount: 100, spent: 120).ratio, greaterThan(1));
  });

  test('Transaction toMap/fromMap round trip', () {
    final t = TransactionModel(
      id: 3,
      amount: 42.5,
      type: 'expense',
      categoryId: 2,
      accountId: 1,
      date: DateTime(2026, 11, 23, 14, 30),
      note: 'غداء',
    );
    final back = TransactionModel.fromMap(t.toMap());
    expect(back.amount, 42.5);
    expect(back.isExpense, true);
    expect(back.date, t.date);
    expect(back.note, 'غداء');
  });

  test('Transfer toMap/fromMap round trip', () {
    final t = TransferModel(fromId: 1, toId: 2, amount: 75, date: DateTime(2026, 11, 23), note: 'x');
    final back = TransferModel.fromMap(t.toMap());
    expect(back.fromId, 1);
    expect(back.toId, 2);
    expect(back.amount, 75);
  });

  test('parseAmount supports Arabic digits and comma', () {
    expect(parseAmount('١٢٣'), 123);
    expect(parseAmount('12,5'), 12.5);
    expect(parseAmount('abc'), isNull);
  });
}
