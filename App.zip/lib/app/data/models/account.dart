import '../../core/utils.dart';

class Account {
  final int? id;
  final int userId;
  final String name;
  final String type; // cash | bank | card | savings
  final double initialBalance;
  final int color;
  final double balance; // محسوب = الافتتاحي + الدخل - المصروف ± التحويلات

  const Account({
    this.id,
    this.userId = 1,
    required this.name,
    required this.type,
    this.initialBalance = 0,
    this.color = 0xFF009688,
    this.balance = 0,
  });

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'user_id': userId,
        'name': name,
        'type': type,
        'initial_balance': initialBalance,
        'color': color,
      };

  factory Account.fromMap(Map<String, Object?> m) => Account(
        id: m['id'] as int?,
        userId: (m['user_id'] as int?) ?? 1,
        name: dn(m['name'] as String),
        type: m['type'] as String,
        initialBalance: (m['initial_balance'] as num).toDouble(),
        color: m['color'] as int,
        balance: ((m['balance'] ?? m['initial_balance']) as num).toDouble(),
      );
}
