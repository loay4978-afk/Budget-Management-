import 'package:get/get.dart';

import '../core/utils.dart';
import '../data/db/database_helper.dart';
import '../data/models/account.dart';
import '../data/models/transfer.dart';
import 'app_controller.dart';
import 'transaction_controller.dart';

class AccountController extends GetxController {
  final _db = DatabaseHelper.instance;
  final accounts = <Account>[].obs;
  final transfers = <TransferModel>[].obs;

  int get _uid => Get.find<AppController>().uid;
  double get total => accounts.fold(0.0, (s, a) => s + a.balance);

  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async {
    accounts.assignAll(await _db.getAccounts(_uid));
    transfers.assignAll(await _db.getTransfers(_uid));
  }

  Future<void> save(Account a) async {
    if (a.id == null) {
      await _db.insertAccount(a);
    } else {
      await _db.updateAccount(a);
    }
    await load();
  }

  Future<void> remove(Account a) async {
    if (accounts.length <= 1) {
      toast('notice'.tr, 'at_least_one_account'.tr, error: true);
      return;
    }
    await _db.deleteAccount(a.id!);
    await Get.find<TransactionController>().refreshAll();
  }

  /// تحويل رصيد بين حسابين لنفس المستخدم
  Future<bool> transfer({
    required int from,
    required int to,
    required double amount,
    required DateTime date,
    String note = '',
  }) async {
    if (from == to) {
      toast('notice'.tr, 'same_account'.tr, error: true);
      return false;
    }
    final src = accounts.firstWhereOrNull((a) => a.id == from);
    if (src == null) return false;
    if (amount > src.balance) {
      toast('notice'.tr, 'insufficient'.tr, error: true);
      return false;
    }
    await _db.insertTransfer(TransferModel(fromId: from, toId: to, amount: amount, date: date, note: note));
    await load();
    return true;
  }

  Future<void> removeTransfer(TransferModel t) async {
    await _db.deleteTransfer(t.id!);
    await load();
  }
}
