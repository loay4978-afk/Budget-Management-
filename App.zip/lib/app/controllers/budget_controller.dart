import 'package:get/get.dart';

import '../core/notification_service.dart';
import '../core/utils.dart';
import '../data/db/database_helper.dart';
import '../data/models/budget.dart';
import 'app_controller.dart';
import 'transaction_controller.dart';

class BudgetController extends GetxController {
  final _db = DatabaseHelper.instance;
  final budgets = <Budget>[].obs;

  AppController get _app => Get.find<AppController>();

  double get totalLimit => budgets.fold(0.0, (s, b) => s + b.amount);
  double get totalSpent => budgets.fold(0.0, (s, b) => s + b.spent);

  /// الميزانيات التي بلغت نسبة التنبيه المحددة أو أكثر
  List<Budget> get alerts => budgets.where((b) => b.ratio >= _app.alertPercent.value / 100).toList();

  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async {
    final tc = Get.find<TransactionController>();
    final list = await _db.getBudgets(_app.uid);
    final txs = await _db.getTransactions(_app.uid, from: tc.monthStart, to: tc.monthEnd, type: 'expense');
    final spent = <int, double>{};
    for (final t in txs) {
      spent[t.categoryId] = (spent[t.categoryId] ?? 0) + t.amount;
    }
    budgets.assignAll(list.map((b) => b.withSpent(spent[b.categoryId] ?? 0)));
  }

  Future<void> save(int categoryId, double amount) async {
    await _db.upsertBudget(_app.uid, categoryId, amount);
    await load();
  }

  Future<void> remove(Budget b) async {
    await _db.deleteBudget(b.id!);
    await load();
  }

  /// يفحص الميزانيات وحد الإنفاق الشهري، وينبّه مرة واحدة فقط لكل تجاوز في الشهر
  Future<void> checkAlerts() async {
    final tc = Get.find<TransactionController>();
    final m = tc.selectedMonth.value;
    final mk = '${_app.uid}:${m.year}-${m.month}';
    final pct = _app.alertPercent.value / 100;

    for (final b in budgets) {
      await _evaluate(
        'b:$mk:${b.id}:over',
        b.ratio >= 1,
        'notif_budget_over_title'.tr,
        'notif_budget_over_body'.trParams({'cat': b.categoryName, 'a': plainNumber(-b.remaining)}),
      );
      await _evaluate(
        'b:$mk:${b.id}:warn',
        b.ratio >= pct && b.ratio < 1,
        'notif_budget_warn_title'.tr,
        'notif_budget_warn_body'.trParams({'cat': b.categoryName, 'p': '${(b.ratio * 100).round()}'}),
      );
    }

    final limit = _app.monthlyLimit.value;
    if (limit > 0) {
      await _evaluate(
        'l:$mk',
        tc.expense > limit,
        'notif_limit_title'.tr,
        'notif_limit_body'.trParams({'a': _app.fmt(tc.expense), 'b': _app.fmt(limit)}),
      );
    }
  }

  Future<void> _evaluate(String key, bool cond, String title, String body) async {
    final was = (await _db.getSetting(key)) == '1';
    if (cond && !was) {
      await _db.setSetting(key, '1');
      toast(title, body, error: true);
      if (_app.notifEnabled.value) {
        await NotificationService.show(key.hashCode & 0x7fffffff, title, body);
      }
    } else if (!cond && was) {
      await _db.setSetting(key, '0');
    }
  }
}
