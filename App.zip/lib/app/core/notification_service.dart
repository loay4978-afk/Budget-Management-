import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';

/// إشعارات النظام (محلية)
class NotificationService {
  NotificationService._();
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> init() async {
    try {
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      const ios = DarwinInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
      );
      await _plugin.initialize(const InitializationSettings(android: android, iOS: ios));
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  /// يطلب إذن الإشعارات (أندرويد 13+ وiOS). يرجع false عند الرفض.
  static Future<bool> requestPermission() async {
    if (!_ready) return false;
    try {
      final a = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      final i = _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
      if (a != null) return (await a.requestNotificationsPermission()) ?? true;
      if (i != null) return (await i.requestPermissions(alert: true, badge: true, sound: true)) ?? false;
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> show(int id, String title, String body) async {
    if (!_ready) return;
    try {
      final details = NotificationDetails(
        android: AndroidNotificationDetails(
          'budget_alerts',
          'notif_channel'.tr,
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: const DarwinNotificationDetails(),
      );
      await _plugin.show(id, title, body, details);
    } catch (_) {}
  }
}
