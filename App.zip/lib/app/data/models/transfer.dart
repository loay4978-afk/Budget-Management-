import '../../core/utils.dart';

class TransferModel {
  final int? id;
  final int fromId;
  final int toId;
  final double amount;
  final DateTime date;
  final String note;
  final String fromName;
  final String toName;

  const TransferModel({
    this.id,
    required this.fromId,
    required this.toId,
    required this.amount,
    required this.date,
    this.note = '',
    this.fromName = '',
    this.toName = '',
  });

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'from_account': fromId,
        'to_account': toId,
        'amount': amount,
        'date': date.toIso8601String(),
        'note': note,
      };

  factory TransferModel.fromMap(Map<String, Object?> m) => TransferModel(
        id: m['id'] as int?,
        fromId: m['from_account'] as int,
        toId: m['to_account'] as int,
        amount: (m['amount'] as num).toDouble(),
        date: DateTime.parse(m['date'] as String),
        note: (m['note'] as String?) ?? '',
        fromName: dn((m['from_name'] as String?) ?? ''),
        toName: dn((m['to_name'] as String?) ?? ''),
      );
}
