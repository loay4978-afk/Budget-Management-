import '../../core/utils.dart';

class CategoryModel {
  final int? id;
  final String name;
  final String type; // expense | income
  final String icon;
  final int color;

  const CategoryModel({this.id, required this.name, required this.type, this.icon = 'other', this.color = 0xFF9E9E9E});

  Map<String, Object?> toMap() =>
      {if (id != null) 'id': id, 'name': name, 'type': type, 'icon': icon, 'color': color};

  factory CategoryModel.fromMap(Map<String, Object?> m) => CategoryModel(
        id: m['id'] as int?,
        name: dn(m['name'] as String),
        type: m['type'] as String,
        icon: m['icon'] as String,
        color: m['color'] as int,
      );
}
