import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show NumberFormat;

import '../core/notification_service.dart';
import '../core/utils.dart';
import '../data/db/database_helper.dart';
import '../data/models/user.dart';
import 'category_controller.dart';
import 'transaction_controller.dart';

/// الإعدادات العامة: المستخدم الحالي + اللغة + المظهر + الإشعارات
class AppController extends GetxController {
  final _db = DatabaseHelper.instance;

  final user = const UserModel(name: '', currency: '\$').obs;
  final users = <UserModel>[].obs;
  final themeMode = ThemeMode.light.obs;
  final lang = 'ar'.obs;
  final notifEnabled = false.obs;
  final monthlyLimit = 0.0.obs; // 0 = بدون حد
  final alertPercent = 80.obs;

  int get uid => user.value.id ?? 1;

  static String _deviceLang() {
    final c = ui.PlatformDispatcher.instance.locale.languageCode;
    return kLangCodes.contains(c) ? c : 'ar';
  }

  static const kLangCodes = ['ar', 'en', 'de'];

  Future<void> load() async {
    user.value = await _db.getCurrentUser();
    users.assignAll(await _db.getUsers());
    themeMode.value = (await _db.getSetting('theme')) == 'dark' ? ThemeMode.dark : ThemeMode.light;
    lang.value = (await _db.getSetting('lang')) ?? _deviceLang();
    notifEnabled.value = (await _db.getSetting('notif')) == '1';
    alertPercent.value = int.tryParse(await _db.getSetting('alert_pct') ?? '') ?? 80;
    monthlyLimit.value = double.tryParse(await _db.getSetting('limit_$uid') ?? '') ?? 0;
  }

  String fmt(double v) => '${NumberFormat('#,##0.##', 'en').format(v)} ${user.value.currency}';

  // ───────── الملف الشخصي ─────────
  Future<void> updateName(String name) async {
    user.value = user.value.copyWith(name: name);
    await _db.updateUser(user.value);
    users.assignAll(await _db.getUsers());
  }

  Future<void> updateCurrency(String c) async {
    user.value = user.value.copyWith(currency: c);
    await _db.updateUser(user.value);
    users.assignAll(await _db.getUsers());
  }

  // ───────── المستخدمون ─────────
  Future<void> switchUser(int id) async {
    await _db.setCurrentUser(id);
    await load();
    await Get.find<TransactionController>().refreshAll();
  }

  Future<void> addUser(String name, String currency) async {
    final id = await _db.insertUser(name, currency);
    await switchUser(id);
  }

  Future<void> removeUser(UserModel u) async {
    if (users.length <= 1) {
      toast('notice'.tr, 'last_user_msg'.tr, error: true);
      return;
    }
    final wasCurrent = u.id == user.value.id;
    await _db.deleteUser(u.id!);
    if (wasCurrent) {
      final rest = await _db.getUsers();
      await _db.setCurrentUser(rest.first.id!);
    }
    await load();
    await Get.find<TransactionController>().refreshAll();
  }

  // ───────── المظهر واللغة ─────────
  Future<void> setDark(bool dark) async {
    themeMode.value = dark ? ThemeMode.dark : ThemeMode.light;
    Get.changeThemeMode(themeMode.value);
    await _db.setSetting('theme', dark ? 'dark' : 'light');
  }

  Future<void> setLang(String code) async {
    lang.value = code;
    await _db.setSetting('lang', code);
    Get.updateLocale(Locale(code));
    // إعادة تحميل البيانات لتتم ترجمة الأسماء الافتراضية
    user.value = await _db.getCurrentUser();
    users.assignAll(await _db.getUsers());
    await Get.find<CategoryController>().load();
    await Get.find<TransactionController>().refreshAll();
  }

  // ───────── الإشعارات ─────────
  Future<void> setNotifEnabled(bool v) async {
    if (v) {
      final ok = await NotificationService.requestPermission();
      if (!ok) {
        toast('notice'.tr, 'notif_denied'.tr, error: true);
        return;
      }
    }
    notifEnabled.value = v;
    await _db.setSetting('notif', v ? '1' : '0');
  }

  Future<void> setMonthlyLimit(double v) async {
    monthlyLimit.value = v;
    await _db.setSetting('limit_$uid', '$v');
  }

  Future<void> setAlertPercent(int v) async {
    alertPercent.value = v;
    await _db.setSetting('alert_pct', '$v');
  }
}
