import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../controllers/transaction_controller.dart';
import '../../core/utils.dart';

class MonthSelector extends StatelessWidget {
  const MonthSelector({super.key});

  @override
  Widget build(BuildContext context) {
    final tc = Get.find<TransactionController>();
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Obx(() => Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => tc.changeMonth(-1)),
              SizedBox(
                width: 170,
                child: Text(
                  DateFormat('MMMM yyyy', lc).format(tc.selectedMonth.value),
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
              ),
              IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => tc.changeMonth(1)),
            ],
          )),
    );
  }
}
