import '../../core/utils.dart';

class UserModel {
  final int? id;
  final String name;
  final String currency;

  const UserModel({this.id, required this.name, required this.currency});

  UserModel copyWith({String? name, String? currency}) =>
      UserModel(id: id, name: name ?? this.name, currency: currency ?? this.currency);

  Map<String, Object?> toMap() => {if (id != null) 'id': id, 'name': name, 'currency': currency};

  factory UserModel.fromMap(Map<String, Object?> m) => UserModel(
        id: m['id'] as int?,
        name: dn(m['name'] as String),
        currency: m['currency'] as String,
      );
}
