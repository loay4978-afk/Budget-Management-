import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../controllers/budget_controller.dart';
import '../controllers/category_controller.dart';
import '../core/constants.dart';
import '../core/utils.dart';
import '../data/models/budget.dart';
import 'widgets/month_selector.dart';

class BudgetsView extends StatelessWidget {
  const BudgetsView({super.key});

  Color _barColor(double r) => r >= 1 ? Colors.red : (r >= 0.8 ? Colors.orange : Colors.green);

  void _openDialog({Budget? edit}) {
    final cc = Get.find<CategoryController>();
    final bc = Get.find<BudgetController>();
    int? catId = edit?.categoryId;
    final ctrl = TextEditingController(text: edit == null ? '' : plainNumber(edit.amount));

    Get.dialog(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text(edit == null ? 'new_budget'.tr : 'edit_budget'.tr),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<int>(
              value: catId,
              hint: Text('category'.tr),
              items: [for (final c in cc.expenseCats) DropdownMenuItem(value: c.id, child: Text(c.name))],
              onChanged: edit == null ? (v) => setState(() => catId = v) : null,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: 'monthly_limit_label'.tr),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: Text('cancel'.tr)),
          FilledButton(
            onPressed: () async {
              final a = parseAmount(ctrl.text);
              if (catId == null || a == null || a <= 0) {
                toast('notice'.tr, 'choose_cat_amount'.tr, error: true);
                return;
              }
              await bc.save(catId!, a);
              Get.back();
            },
            child: Text('save'.tr),
          ),
        ],
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final bc = Get.find<BudgetController>();
    final app = Get.find<AppController>();

    return Scaffold(
      appBar: AppBar(
        title: Text('nav_budget'.tr),
        actions: [IconButton(icon: const Icon(Icons.add), tooltip: 'new_budget'.tr, onPressed: () => _openDialog())],
      ),
      body: Obx(() {
        final list = bc.budgets;
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
          children: [
            const MonthSelector(),
            if (list.isEmpty)
              Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  children: [
                    Text('no_budget_msg'.tr, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton.icon(onPressed: () => _openDialog(), icon: const Icon(Icons.add), label: Text('add_budget'.tr)),
                  ],
                ),
              )
            else ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('total_budgets'.tr),
                      const SizedBox(height: 4),
                      Text('x_of_y'.trParams({'a': app.fmt(bc.totalSpent), 'b': app.fmt(bc.totalLimit)}),
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 10),
                      LinearProgressIndicator(
                        value: bc.totalLimit == 0 ? 0 : (bc.totalSpent / bc.totalLimit).clamp(0.0, 1.0),
                        minHeight: 8,
                        borderRadius: BorderRadius.circular(8),
                        color: _barColor(bc.totalLimit == 0 ? 0 : bc.totalSpent / bc.totalLimit),
                      ),
                    ],
                  ),
                ),
              ),
              for (final b in list)
                Card(
                  child: Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(16, 8, 8, 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 18,
                              backgroundColor: Color(b.color).withOpacity(0.15),
                              child: Icon(iconOf(b.icon), size: 20, color: Color(b.color)),
                            ),
                            const SizedBox(width: 10),
                            Expanded(child: Text(b.categoryName, style: const TextStyle(fontWeight: FontWeight.bold))),
                            Text('${(b.ratio * 100).round()}%', style: TextStyle(color: _barColor(b.ratio), fontWeight: FontWeight.bold)),
                            PopupMenuButton<String>(
                              onSelected: (v) async {
                                if (v == 'edit') {
                                  _openDialog(edit: b);
                                } else if (await confirm('delete_budget'.tr, 'delete_budget_msg'.trParams({'cat': b.categoryName}))) {
                                  await bc.remove(b);
                                }
                              },
                              itemBuilder: (_) => [
                                PopupMenuItem(value: 'edit', child: Text('edit'.tr)),
                                PopupMenuItem(value: 'delete', child: Text('delete'.tr)),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Padding(
                          padding: const EdgeInsetsDirectional.only(end: 8),
                          child: LinearProgressIndicator(
                            value: b.ratio.clamp(0.0, 1.0),
                            minHeight: 10,
                            borderRadius: BorderRadius.circular(8),
                            color: _barColor(b.ratio),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text('spent_of'.trParams({'a': app.fmt(b.spent), 'b': app.fmt(b.amount)}), style: Theme.of(context).textTheme.bodySmall),
                        Text(
                          b.remaining >= 0
                              ? 'remaining'.trParams({'a': app.fmt(b.remaining)})
                              : 'exceeded_by'.trParams({'a': app.fmt(-b.remaining)}),
                          style: TextStyle(color: b.remaining >= 0 ? Colors.green.shade700 : Colors.red, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ],
        );
      }),
    );
  }
}
