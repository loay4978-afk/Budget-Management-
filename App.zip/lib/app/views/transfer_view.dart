import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../controllers/account_controller.dart';
import '../controllers/app_controller.dart';
import '../core/utils.dart';

class TransferView extends StatefulWidget {
  const TransferView({super.key});

  @override
  State<TransferView> createState() => _TransferViewState();
}

class _TransferViewState extends State<TransferView> {
  final ac = Get.find<AccountController>();
  final app = Get.find<AppController>();
  int? fromId;
  int? toId;
  DateTime date = DateTime.now();
  final amountCtrl = TextEditingController();
  final noteCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (ac.accounts.length >= 2) {
      fromId = ac.accounts[0].id;
      toId = ac.accounts[1].id;
    }
  }

  @override
  void dispose() {
    amountCtrl.dispose();
    noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final p = await showDatePicker(context: context, initialDate: date, firstDate: DateTime(2000), lastDate: DateTime(2100));
    if (p != null) setState(() => date = DateTime(p.year, p.month, p.day, date.hour, date.minute));
  }

  Future<void> _submit() async {
    final amount = parseAmount(amountCtrl.text);
    if (amount == null || amount <= 0) return toast('notice'.tr, 'enter_amount'.tr, error: true);
    if (fromId == null || toId == null) return toast('notice'.tr, 'choose_account'.tr, error: true);
    final ok = await ac.transfer(from: fromId!, to: toId!, amount: amount, date: date, note: noteCtrl.text.trim());
    if (ok) {
      amountCtrl.clear();
      noteCtrl.clear();
      toast('transfer_title'.tr, 'transfer_done'.tr);
    }
  }

  Widget _dropdown(String label, int? value, ValueChanged<int?> onChanged) => DropdownButtonFormField<int>(
        value: value,
        decoration: InputDecoration(labelText: label),
        items: [
          for (final a in ac.accounts)
            DropdownMenuItem(value: a.id, child: Text('${a.name}  (${app.fmt(a.balance)})', overflow: TextOverflow.ellipsis)),
        ],
        onChanged: onChanged,
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('transfer_title'.tr)),
      body: Obx(() {
        if (ac.accounts.length < 2) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Text('need_two_accounts'.tr, textAlign: TextAlign.center),
            ),
          );
        }
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _dropdown('from_account'.tr, fromId, (v) => setState(() => fromId = v)),
            Center(
              child: IconButton(
                icon: const Icon(Icons.swap_vert),
                onPressed: () => setState(() {
                  final t = fromId;
                  fromId = toId;
                  toId = t;
                }),
              ),
            ),
            _dropdown('to_account'.tr, toId, (v) => setState(() => toId = v)),
            const SizedBox(height: 16),
            TextField(
              controller: amountCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              decoration: InputDecoration(labelText: 'amount'.tr, suffixText: app.user.value.currency),
            ),
            const SizedBox(height: 16),
            ListTile(
              shape: RoundedRectangleBorder(
                side: BorderSide(color: Theme.of(context).colorScheme.outline),
                borderRadius: BorderRadius.circular(4),
              ),
              leading: const Icon(Icons.calendar_today),
              title: Text(DateFormat('EEEE d MMMM yyyy', lc).format(date)),
              onTap: _pickDate,
            ),
            const SizedBox(height: 16),
            TextField(controller: noteCtrl, decoration: InputDecoration(labelText: 'note_optional'.tr)),
            const SizedBox(height: 20),
            FilledButton.icon(onPressed: _submit, icon: const Icon(Icons.swap_horiz), label: Text('do_transfer'.tr)),
            const SizedBox(height: 24),
            Text('transfer_history'.tr, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (ac.transfers.isEmpty)
              Padding(padding: const EdgeInsets.all(16), child: Center(child: Text('no_transfers'.tr)))
            else
              for (final t in ac.transfers)
                Card(
                  child: ListTile(
                    title: Row(children: [
                      Flexible(child: Text(t.fromName, overflow: TextOverflow.ellipsis)),
                      const Padding(padding: EdgeInsets.symmetric(horizontal: 6), child: Icon(Icons.arrow_forward, size: 16)),
                      Flexible(child: Text(t.toName, overflow: TextOverflow.ellipsis)),
                    ]),
                    subtitle: Text([
                      DateFormat('d MMM yyyy • HH:mm', lc).format(t.date),
                      if (t.note.isNotEmpty) t.note,
                    ].join(' • ')),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(app.fmt(t.amount), textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.bold)),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          if (await confirm('delete_transfer'.tr, 'delete_transfer_msg'.tr)) await ac.removeTransfer(t);
                        },
                      ),
                    ]),
                  ),
                ),
          ],
        );
      }),
    );
  }
}
