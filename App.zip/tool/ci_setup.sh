#!/usr/bin/env bash
# يُشغَّل بعد `flutter create .` لتهيئة إعدادات أندرويد (إشعارات + اسم التطبيق)
set -e
MANIFEST=android/app/src/main/AndroidManifest.xml

# 1) إذن الإشعارات (أندرويد 13+)
if ! grep -q POST_NOTIFICATIONS "$MANIFEST"; then
  sed -i '0,/<application/s#<application#<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n    <application#' "$MANIFEST"
fi

# 2) اسم التطبيق تحت الأيقونة
sed -i 's#android:label="[^"]*"#android:label="Masrofi"#' "$MANIFEST"

# 3) Core library desugaring (مطلوب لحزمة flutter_local_notifications)
if [ -f android/app/build.gradle.kts ]; then
  F=android/app/build.gradle.kts
  sed -i '0,/compileOptions {/s#compileOptions {#compileOptions {\n        isCoreLibraryDesugaringEnabled = true#' "$F"
  printf '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n' >> "$F"
else
  F=android/app/build.gradle
  sed -i '0,/compileOptions {/s#compileOptions {#compileOptions {\n        coreLibraryDesugaringEnabled true#' "$F"
  printf '\ndependencies {\n    coreLibraryDesugaring "com.android.tools:desugar_jdk_libs:2.1.4"\n}\n' >> "$F"
fi
echo "ci_setup done"
