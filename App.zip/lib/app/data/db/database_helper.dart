import 'dart:ui' as ui;

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/account.dart';
import '../models/budget.dart';
import '../models/category.dart';
import '../models/transaction.dart';
import '../models/transfer.dart';
import '../models/user.dart';

class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();

  Database? _db;
  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'masrofi.db');
    return openDatabase(
      path,
      version: 2,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  static String _defaultCurrency() {
    switch (ui.PlatformDispatcher.instance.locale.languageCode) {
      case 'de':
        return '€';
      case 'en':
        return '\$';
      default:
        return 'ر.س';
    }
  }

  Future<void> _createTransfers(Database db) async {
    await db.execute('''CREATE TABLE transfers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      from_account INTEGER NOT NULL, to_account INTEGER NOT NULL,
      amount REAL NOT NULL, date TEXT NOT NULL, note TEXT,
      FOREIGN KEY(from_account) REFERENCES accounts(id) ON DELETE CASCADE,
      FOREIGN KEY(to_account) REFERENCES accounts(id) ON DELETE CASCADE)''');
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''CREATE TABLE users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, currency TEXT NOT NULL)''');
    await db.execute('''CREATE TABLE accounts(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL DEFAULT 1,
      name TEXT NOT NULL, type TEXT NOT NULL,
      initial_balance REAL NOT NULL DEFAULT 0, color INTEGER NOT NULL)''');
    await db.execute('''CREATE TABLE categories(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, type TEXT NOT NULL,
      icon TEXT NOT NULL, color INTEGER NOT NULL)''');
    await db.execute('''CREATE TABLE transactions(
      id INTEGER PRIMARY KEY AUTOINCREMENT, amount REAL NOT NULL, type TEXT NOT NULL,
      category_id INTEGER NOT NULL, account_id INTEGER NOT NULL, date TEXT NOT NULL, note TEXT,
      FOREIGN KEY(category_id) REFERENCES categories(id),
      FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE)''');
    await _createBudgets(db, 'budgets');
    await db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
    await db.execute('CREATE INDEX idx_tx_date ON transactions(date)');
    await _createTransfers(db);

    await db.insert('users', {'name': 'k_friend', 'currency': _defaultCurrency()});
    await db.insert('accounts', {'user_id': 1, 'name': 'k_wallet', 'type': 'cash', 'initial_balance': 0, 'color': 0xFF009688});
    const expense = [
      ['k_food', 'food', 0xFFFB8C00],
      ['k_transport', 'transport', 0xFF039BE5],
      ['k_shopping', 'shopping', 0xFFD81B60],
      ['k_bills', 'bills', 0xFF3949AB],
      ['k_health', 'health', 0xFFE53935],
      ['k_education', 'education', 0xFF8E24AA],
      ['k_entertainment', 'entertainment', 0xFF43A047],
      ['k_home', 'home', 0xFF6D4C41],
      ['k_other', 'other', 0xFF757575],
    ];
    const income = [
      ['k_salary', 'salary', 0xFF2E7D32],
      ['k_freelance', 'business', 0xFF00897B],
      ['k_invest', 'invest', 0xFF1E88E5],
      ['k_gifts', 'gift', 0xFFAD1457],
    ];
    for (final c in expense) {
      await db.insert('categories', {'name': c[0], 'type': 'expense', 'icon': c[1], 'color': c[2]});
    }
    for (final c in income) {
      await db.insert('categories', {'name': c[0], 'type': 'income', 'icon': c[1], 'color': c[2]});
    }
  }

  Future<void> _createBudgets(Database db, String name) async {
    await db.execute('''CREATE TABLE $name(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL DEFAULT 1,
      category_id INTEGER NOT NULL, amount REAL NOT NULL,
      UNIQUE(user_id, category_id),
      FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE)''');
  }

  Future<void> _onUpgrade(Database db, int oldV, int newV) async {
    if (oldV < 2) {
      await db.execute('ALTER TABLE accounts ADD COLUMN user_id INTEGER NOT NULL DEFAULT 1');
      await _createBudgets(db, 'budgets_new');
      await db.execute(
          'INSERT INTO budgets_new(id, user_id, category_id, amount) SELECT id, 1, category_id, amount FROM budgets');
      await db.execute('DROP TABLE budgets');
      await db.execute('ALTER TABLE budgets_new RENAME TO budgets');
      await _createTransfers(db);

      const names = {
        'الطعام': 'k_food',
        'المواصلات': 'k_transport',
        'التسوق': 'k_shopping',
        'الفواتير': 'k_bills',
        'الصحة': 'k_health',
        'التعليم': 'k_education',
        'الترفيه': 'k_entertainment',
        'المنزل': 'k_home',
        'أخرى': 'k_other',
        'الراتب': 'k_salary',
        'عمل حر': 'k_freelance',
        'استثمار': 'k_invest',
        'هدايا': 'k_gifts',
      };
      for (final e in names.entries) {
        await db.update('categories', {'name': e.value}, where: 'name = ?', whereArgs: [e.key]);
      }
      await db.update('accounts', {'name': 'k_wallet'}, where: 'name = ?', whereArgs: ['المحفظة']);
      await db.update('users', {'name': 'k_friend'}, where: 'name = ?', whereArgs: ['صديقي']);
    }
  }

  // ───────── الإعدادات ─────────
  Future<String?> getSetting(String key) async {
    final d = await database;
    final r = await d.query('settings', where: 'key = ?', whereArgs: [key]);
    return r.isEmpty ? null : r.first['value'] as String?;
  }

  Future<void> setSetting(String key, String value) async {
    final d = await database;
    await d.insert('settings', {'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ───────── المستخدمون ─────────
  Future<UserModel> getCurrentUser() async {
    final d = await database;
    final cur = int.tryParse(await getSetting('current_user') ?? '');
    var r = <Map<String, Object?>>[];
    if (cur != null) r = await d.query('users', where: 'id = ?', whereArgs: [cur]);
    if (r.isEmpty) {
      r = await d.query('users', orderBy: 'id', limit: 1);
      await setSetting('current_user', '${r.first['id']}');
    }
    return UserModel.fromMap(r.first);
  }

  Future<void> setCurrentUser(int id) => setSetting('current_user', '$id');

  Future<List<UserModel>> getUsers() async {
    final r = await (await database).query('users', orderBy: 'id');
    return r.map(UserModel.fromMap).toList();
  }

  Future<int> insertUser(String name, String currency) async {
    final d = await database;
    final id = await d.insert('users', {'name': name, 'currency': currency});
    await d.insert('accounts', {'user_id': id, 'name': 'k_wallet', 'type': 'cash', 'initial_balance': 0, 'color': 0xFF009688});
    return id;
  }

  Future<void> updateUser(UserModel u) async {
    final d = await database;
    await d.update('users', u.toMap(), where: 'id = ?', whereArgs: [u.id]);
  }

  Future<void> deleteUser(int id) async {
    final d = await database;
    await d.delete('accounts', where: 'user_id = ?', whereArgs: [id]); // تحذف عملياتها وتحويلاتها
    await d.delete('budgets', where: 'user_id = ?', whereArgs: [id]);
    await d.delete('users', where: 'id = ?', whereArgs: [id]);
  }

  // ───────── الحسابات ─────────
  Future<List<Account>> getAccounts(int userId) async {
    final d = await database;
    final r = await d.rawQuery('''
      SELECT a.*,
        a.initial_balance
        + COALESCE((SELECT SUM(CASE WHEN t.type = 'income' THEN t.amount ELSE -t.amount END)
                    FROM transactions t WHERE t.account_id = a.id), 0)
        - COALESCE((SELECT SUM(amount) FROM transfers WHERE from_account = a.id), 0)
        + COALESCE((SELECT SUM(amount) FROM transfers WHERE to_account = a.id), 0) AS balance
      FROM accounts a WHERE a.user_id = ? ORDER BY a.id''', [userId]);
    return r.map(Account.fromMap).toList();
  }

  Future<int> insertAccount(Account a) async => (await database).insert('accounts', a.toMap());

  Future<void> updateAccount(Account a) async =>
      (await database).update('accounts', a.toMap(), where: 'id = ?', whereArgs: [a.id]);

  Future<void> deleteAccount(int id) async =>
      (await database).delete('accounts', where: 'id = ?', whereArgs: [id]);

  // ───────── التحويلات ─────────
  Future<List<TransferModel>> getTransfers(int userId) async {
    final r = await (await database).rawQuery('''
      SELECT tr.*, fa.name AS from_name, ta.name AS to_name
      FROM transfers tr
      JOIN accounts fa ON fa.id = tr.from_account
      JOIN accounts ta ON ta.id = tr.to_account
      WHERE fa.user_id = ?
      ORDER BY tr.date DESC, tr.id DESC''', [userId]);
    return r.map(TransferModel.fromMap).toList();
  }

  Future<int> insertTransfer(TransferModel t) async => (await database).insert('transfers', t.toMap());

  Future<void> deleteTransfer(int id) async =>
      (await database).delete('transfers', where: 'id = ?', whereArgs: [id]);

  // ───────── الفئات ─────────
  Future<List<CategoryModel>> getCategories() async {
    final r = await (await database).query('categories', orderBy: 'id');
    return r.map(CategoryModel.fromMap).toList();
  }

  Future<int> insertCategory(CategoryModel c) async => (await database).insert('categories', c.toMap());

  /// يرجع false إذا كانت الفئة مستخدمة في عمليات
  Future<bool> deleteCategory(int id) async {
    final d = await database;
    final n = Sqflite.firstIntValue(
        await d.rawQuery('SELECT COUNT(*) FROM transactions WHERE category_id = ?', [id]));
    if ((n ?? 0) > 0) return false;
    await d.delete('categories', where: 'id = ?', whereArgs: [id]);
    return true;
  }

  // ───────── العمليات ─────────
  Future<List<TransactionModel>> getTransactions(int userId,
      {DateTime? from, DateTime? to, String? type}) async {
    final d = await database;
    final where = <String>['a.user_id = ?'];
    final args = <Object?>[userId];
    if (from != null) {
      where.add('t.date >= ?');
      args.add(from.toIso8601String());
    }
    if (to != null) {
      where.add('t.date < ?');
      args.add(to.toIso8601String());
    }
    if (type != null) {
      where.add('t.type = ?');
      args.add(type);
    }
    final r = await d.rawQuery('''
      SELECT t.*, c.name AS category_name, c.icon AS category_icon, c.color AS category_color, a.name AS account_name
      FROM transactions t
      JOIN categories c ON c.id = t.category_id
      JOIN accounts a ON a.id = t.account_id
      WHERE ${where.join(' AND ')}
      ORDER BY t.date DESC, t.id DESC''', args);
    return r.map(TransactionModel.fromMap).toList();
  }

  Future<int> insertTransaction(TransactionModel t) async => (await database).insert('transactions', t.toMap());

  Future<void> updateTransaction(TransactionModel t) async =>
      (await database).update('transactions', t.toMap(), where: 'id = ?', whereArgs: [t.id]);

  Future<void> deleteTransaction(int id) async =>
      (await database).delete('transactions', where: 'id = ?', whereArgs: [id]);

  // ───────── الميزانيات ─────────
  Future<List<Budget>> getBudgets(int userId) async {
    final r = await (await database).rawQuery('''
      SELECT b.*, c.name AS category_name, c.icon AS category_icon, c.color AS category_color
      FROM budgets b JOIN categories c ON c.id = b.category_id
      WHERE b.user_id = ? ORDER BY b.id''', [userId]);
    return r.map(Budget.fromMap).toList();
  }

  Future<void> upsertBudget(int userId, int categoryId, double amount) async {
    await (await database).insert('budgets', {'user_id': userId, 'category_id': categoryId, 'amount': amount},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteBudget(int id) async =>
      (await database).delete('budgets', where: 'id = ?', whereArgs: [id]);
}
