import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'app/bindings/initial_binding.dart';
import 'app/controllers/app_controller.dart';
import 'app/core/notification_service.dart';
import 'app/data/db/database_helper.dart';
import 'app/routes/app_pages.dart';
import 'app/theme/app_theme.dart';
import 'app/translations/app_translations.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting(); // كل اللغات (ar / en / de)
  await DatabaseHelper.instance.database;
  await NotificationService.init();
  final app = Get.put(AppController(), permanent: true);
  await app.load();
  runApp(const MasrofiApp());
}

class MasrofiApp extends StatelessWidget {
  const MasrofiApp({super.key});

  @override
  Widget build(BuildContext context) {
    final app = Get.find<AppController>();
    return GetMaterialApp(
      title: 'Masrofi',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: app.themeMode.value,
      translations: AppTranslations(),
      locale: Locale(app.lang.value),
      fallbackLocale: const Locale('en'),
      supportedLocales: const [Locale('ar'), Locale('en'), Locale('de')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      initialBinding: InitialBinding(),
      initialRoute: Routes.home,
      getPages: AppPages.pages,
    );
  }
}
