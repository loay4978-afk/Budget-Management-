import 'package:flutter/material.dart';

/// أيقونات الفئات (تُخزَّن كمفتاح نصي في قاعدة البيانات)
const Map<String, IconData> kIcons = {
  'food': Icons.restaurant,
  'transport': Icons.directions_car,
  'shopping': Icons.shopping_bag,
  'bills': Icons.receipt_long,
  'health': Icons.favorite,
  'education': Icons.school,
  'entertainment': Icons.movie,
  'home': Icons.home,
  'travel': Icons.flight,
  'gift': Icons.card_giftcard,
  'salary': Icons.payments,
  'business': Icons.work,
  'invest': Icons.trending_up,
  'other': Icons.category,
};

IconData iconOf(String key) => kIcons[key] ?? Icons.category;

const List<int> kPalette = [
  0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF00897B,
  0xFF039BE5, 0xFF3949AB, 0xFF8E24AA, 0xFFD81B60, 0xFF6D4C41,
];

/// القيمة = مفتاح الترجمة
const Map<String, String> kAccountTypes = {
  'cash': 'acc_cash',
  'bank': 'acc_bank',
  'card': 'acc_card',
  'savings': 'acc_savings',
};

const Map<String, IconData> kAccountIcons = {
  'cash': Icons.payments,
  'bank': Icons.account_balance,
  'card': Icons.credit_card,
  'savings': Icons.savings,
};

const List<String> kCurrencies = [
  '\$', '€', '£', 'SAR', 'AED', 'EGP', 'TRY',
  'ر.س', 'ر.ي', 'د.إ', 'ج.م', 'د.ك', 'ر.ق', 'د.ب', 'ر.ع', 'د.أ', 'ل.س',
];

const Map<String, String> kLanguages = {
  'ar': 'العربية',
  'en': 'English',
  'de': 'Deutsch',
};
