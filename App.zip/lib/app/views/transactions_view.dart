import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/transaction_controller.dart';
import 'widgets/month_selector.dart';
import 'widgets/transaction_tile.dart';

class TransactionsView extends StatelessWidget {
  const TransactionsView({super.key});

  @override
  Widget build(BuildContext context) {
    final tc = Get.find<TransactionController>();
    return Scaffold(
      appBar: AppBar(title: Text('nav_transactions'.tr)),
      body: Column(
        children: [
          const MonthSelector(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              onChanged: (v) => tc.search.value = v,
              decoration: InputDecoration(
                hintText: 'search_hint'.tr,
                prefixIcon: const Icon(Icons.search),
                isDense: true,
              ),
            ),
          ),
          Obx(() => Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    for (final f in const [['', 'all'], ['expense', 'expenses_plural'], ['income', 'incomes_plural']])
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 8),
                        child: ChoiceChip(
                          label: Text(f[1].tr),
                          selected: tc.typeFilter.value == f[0],
                          onSelected: (_) => tc.typeFilter.value = f[0],
                        ),
                      ),
                  ],
                ),
              )),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text('tx_hint'.tr, style: Theme.of(context).textTheme.bodySmall),
            ),
          ),
          Expanded(
            child: Obx(() {
              final list = tc.filtered;
              if (list.isEmpty) return Center(child: Text('no_transactions'.tr));
              return ListView.separated(
                padding: const EdgeInsets.only(bottom: 96),
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) => TransactionTile(t: list[i]),
              );
            }),
          ),
        ],
      ),
    );
  }
}
