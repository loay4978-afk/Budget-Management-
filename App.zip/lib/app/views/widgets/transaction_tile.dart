import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../controllers/app_controller.dart';
import '../../controllers/transaction_controller.dart';
import '../../core/constants.dart';
import '../../core/utils.dart';
import '../../data/models/transaction.dart';
import '../../routes/app_pages.dart';

class TransactionTile extends StatelessWidget {
  final TransactionModel t;
  const TransactionTile({super.key, required this.t});

  Future<void> _delete(TransactionController tc) async {
    if (await confirm('delete_tx'.tr, 'delete_tx_msg'.tr)) await tc.remove(t);
  }

  @override
  Widget build(BuildContext context) {
    final app = Get.find<AppController>();
    final tc = Get.find<TransactionController>();
    final color = t.isExpense ? Colors.red.shade600 : Colors.green.shade600;
    final cat = Color(t.categoryColor);

    return Dismissible(
      key: ValueKey('tx${t.id}'),
      direction: DismissDirection.horizontal,
      background: Container(
        color: Colors.red,
        alignment: AlignmentDirectional.centerEnd,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      confirmDismiss: (_) async {
        await _delete(tc);
        return false; // القائمة تُحدَّث من المصدر
      },
      child: ListTile(
        onTap: () => Get.toNamed(Routes.addTransaction, arguments: t),
        onLongPress: () => Get.bottomSheet(
          SafeArea(
            child: Wrap(children: [
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: Text('edit'.tr),
                onTap: () {
                  Get.back();
                  Get.toNamed(Routes.addTransaction, arguments: t);
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.red),
                title: Text('delete'.tr, style: const TextStyle(color: Colors.red)),
                onTap: () async {
                  Get.back();
                  await _delete(tc);
                },
              ),
            ]),
          ),
          backgroundColor: Theme.of(context).colorScheme.surface,
        ),
        leading: CircleAvatar(
          backgroundColor: cat.withOpacity(0.15),
          child: Icon(iconOf(t.categoryIcon), color: cat),
        ),
        title: Text(t.categoryName),
        subtitle: Text(
          [
            t.accountName,
            DateFormat('d MMM • HH:mm', lc).format(t.date),
            if (t.note.isNotEmpty) t.note,
          ].join(' • '),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: Text(
          '${t.isExpense ? '-' : '+'}${app.fmt(t.amount)}',
          textDirection: TextDirection.ltr,
          style: TextStyle(color: color, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
