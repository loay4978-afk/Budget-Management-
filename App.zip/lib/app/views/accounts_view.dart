import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/account_controller.dart';
import '../controllers/app_controller.dart';
import '../core/constants.dart';
import '../core/utils.dart';
import '../data/models/account.dart';
import '../routes/app_pages.dart';

class AccountsView extends StatelessWidget {
  const AccountsView({super.key});

  void _openDialog([Account? edit]) {
    final ac = Get.find<AccountController>();
    final app = Get.find<AppController>();
    final name = TextEditingController(text: edit?.name ?? '');
    final bal = TextEditingController(text: edit == null ? '0' : plainNumber(edit.initialBalance));
    String type = edit?.type ?? 'cash';

    Get.dialog(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text(edit == null ? 'new_account'.tr : 'edit_account'.tr),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: InputDecoration(labelText: 'account_name'.tr)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: type,
              decoration: InputDecoration(labelText: 'account_type'.tr),
              items: [for (final e in kAccountTypes.entries) DropdownMenuItem(value: e.key, child: Text(e.value.tr))],
              onChanged: (v) => setState(() => type = v ?? 'cash'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: bal,
              keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
              decoration: InputDecoration(labelText: 'initial_balance'.tr),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: Text('cancel'.tr)),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) {
                toast('notice'.tr, 'enter_name'.tr, error: true);
                return;
              }
              await ac.save(Account(
                id: edit?.id,
                userId: app.uid,
                name: name.text.trim(),
                type: type,
                initialBalance: parseAmount(bal.text) ?? 0,
                color: edit?.color ?? kPalette[ac.accounts.length % kPalette.length],
              ));
              Get.back();
            },
            child: Text('save'.tr),
          ),
        ],
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final ac = Get.find<AccountController>();
    final app = Get.find<AppController>();
    return Scaffold(
      appBar: AppBar(
        title: Text('accounts_title'.tr),
        actions: [
          IconButton(
            icon: const Icon(Icons.swap_horiz),
            tooltip: 'transfer_title'.tr,
            onPressed: () => Get.toNamed(Routes.transfer),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(onPressed: () => _openDialog(), child: const Icon(Icons.add)),
      body: Obx(() => ListView(
            padding: const EdgeInsets.only(bottom: 96),
            children: [
              ListTile(
                title: Text('total'.tr),
                trailing: Text(app.fmt(ac.total), textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              ),
              const Divider(),
              for (final a in ac.accounts)
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Color(a.color).withOpacity(0.15),
                    child: Icon(kAccountIcons[a.type] ?? Icons.payments, color: Color(a.color)),
                  ),
                  title: Text(a.name),
                  subtitle: Text((kAccountTypes[a.type] ?? 'acc_cash').tr),
                  onTap: () => _openDialog(a),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(app.fmt(a.balance),
                          textDirection: TextDirection.ltr,
                          style: TextStyle(fontWeight: FontWeight.bold, color: a.balance < 0 ? Colors.red : null)),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          if (await confirm('delete_account'.tr, 'delete_account_msg'.trParams({'n': a.name}))) {
                            await ac.remove(a);
                          }
                        },
                      ),
                    ],
                  ),
                ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: OutlinedButton.icon(
                  onPressed: () => Get.toNamed(Routes.transfer),
                  icon: const Icon(Icons.swap_horiz),
                  label: Text('transfer_title'.tr),
                ),
              ),
            ],
          )),
    );
  }
}
