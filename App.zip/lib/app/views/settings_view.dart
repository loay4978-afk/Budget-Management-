import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../controllers/transaction_controller.dart';
import '../core/constants.dart';
import '../core/utils.dart';
import '../routes/app_pages.dart';

class SettingsView extends StatelessWidget {
  const SettingsView({super.key});

  void _editName(AppController app) {
    final ctrl = TextEditingController(text: app.user.value.name);
    Get.dialog(AlertDialog(
      title: Text('name'.tr),
      content: TextField(controller: ctrl, autofocus: true),
      actions: [
        TextButton(onPressed: () => Get.back(), child: Text('cancel'.tr)),
        FilledButton(
          onPressed: () async {
            if (ctrl.text.trim().isNotEmpty) await app.updateName(ctrl.text.trim());
            Get.back();
          },
          child: Text('save'.tr),
        ),
      ],
    ));
  }

  void _pickCurrency(AppController app) {
    Get.dialog(SimpleDialog(
      title: Text('currency'.tr),
      children: [
        for (final c in kCurrencies)
          SimpleDialogOption(
            onPressed: () async {
              await app.updateCurrency(c);
              await Get.find<TransactionController>().refreshAll();
              Get.back();
            },
            child: Text(c, style: const TextStyle(fontSize: 16)),
          ),
      ],
    ));
  }

  void _pickLanguage(AppController app) {
    Get.dialog(SimpleDialog(
      title: Text('language'.tr),
      children: [
        for (final e in kLanguages.entries)
          SimpleDialogOption(
            onPressed: () async {
              Get.back();
              await app.setLang(e.key);
            },
            child: Row(children: [
              Icon(app.lang.value == e.key ? Icons.radio_button_checked : Icons.radio_button_off, size: 20),
              const SizedBox(width: 12),
              Text(e.value, style: const TextStyle(fontSize: 16)),
            ]),
          ),
      ],
    ));
  }

  void _editLimit(AppController app) {
    final ctrl = TextEditingController(text: app.monthlyLimit.value > 0 ? plainNumber(app.monthlyLimit.value) : '');
    Get.dialog(AlertDialog(
      title: Text('monthly_limit'.tr),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('monthly_limit_desc'.tr, style: Theme.of(Get.context!).textTheme.bodySmall),
          const SizedBox(height: 12),
          TextField(
            controller: ctrl,
            autofocus: true,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: 'amount'.tr, suffixText: app.user.value.currency),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () async {
            await app.setMonthlyLimit(0);
            Get.back();
          },
          child: Text('remove_limit'.tr),
        ),
        FilledButton(
          onPressed: () async {
            final v = parseAmount(ctrl.text);
            if (v == null || v < 0) {
              toast('notice'.tr, 'enter_amount'.tr, error: true);
              return;
            }
            await app.setMonthlyLimit(v);
            Get.back();
          },
          child: Text('save'.tr),
        ),
      ],
    ));
  }

  void _editPercent(AppController app) {
    double v = app.alertPercent.value.toDouble();
    Get.dialog(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text('alert_percent'.tr),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('alert_percent_desc'.tr, style: Theme.of(ctx).textTheme.bodySmall),
            const SizedBox(height: 12),
            Text('${v.round()}%', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            Slider(
              value: v,
              min: 50,
              max: 100,
              divisions: 10,
              label: '${v.round()}%',
              onChanged: (x) => setState(() => v = x),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: Text('cancel'.tr)),
          FilledButton(
            onPressed: () async {
              await app.setAlertPercent(v.round());
              Get.back();
            },
            child: Text('save'.tr),
          ),
        ],
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final app = Get.find<AppController>();
    final grey = Theme.of(context).colorScheme.onSurface.withOpacity(0.55);
    return Scaffold(
      appBar: AppBar(title: Text('settings_title'.tr)),
      body: Obx(() => ListView(
            children: [
              ListTile(
                leading: const Icon(Icons.person_outline),
                title: Text('name'.tr),
                subtitle: Text(app.user.value.name),
                onTap: () => _editName(app),
              ),
              ListTile(
                leading: const Icon(Icons.people_outline),
                title: Text('users_title'.tr),
                subtitle: Text('users_count'.trParams({'n': '${app.users.length}'})),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Get.toNamed(Routes.users),
              ),
              ListTile(
                leading: const Icon(Icons.attach_money),
                title: Text('currency'.tr),
                subtitle: Text(app.user.value.currency),
                onTap: () => _pickCurrency(app),
              ),
              ListTile(
                leading: const Icon(Icons.language),
                title: Text('language'.tr),
                subtitle: Text(kLanguages[app.lang.value] ?? ''),
                onTap: () => _pickLanguage(app),
              ),
              SwitchListTile(
                secondary: const Icon(Icons.dark_mode_outlined),
                title: Text('dark_mode'.tr),
                value: app.themeMode.value == ThemeMode.dark,
                onChanged: app.setDark,
              ),
              const Divider(),
              _Section('notifications'.tr),
              SwitchListTile(
                secondary: const Icon(Icons.notifications_active_outlined),
                title: Text('enable_notifications'.tr),
                subtitle: Text('enable_notifications_desc'.tr),
                value: app.notifEnabled.value,
                onChanged: app.setNotifEnabled,
              ),
              ListTile(
                leading: const Icon(Icons.speed),
                title: Text('monthly_limit'.tr),
                subtitle: Text(app.monthlyLimit.value > 0 ? app.fmt(app.monthlyLimit.value) : 'no_limit'.tr),
                onTap: () => _editLimit(app),
              ),
              ListTile(
                leading: const Icon(Icons.percent),
                title: Text('alert_percent'.tr),
                subtitle: Text('${app.alertPercent.value}%'),
                onTap: () => _editPercent(app),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.category_outlined),
                title: Text('categories_title'.tr),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Get.toNamed(Routes.categories),
              ),
              ListTile(
                leading: const Icon(Icons.account_balance_wallet_outlined),
                title: Text('accounts_title'.tr),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Get.toNamed(Routes.accounts),
              ),
              ListTile(
                leading: const Icon(Icons.ios_share),
                title: Text('export_data'.tr),
                onTap: () async {
                  try {
                    await Get.find<TransactionController>().exportCsv();
                  } catch (e) {
                    toast('error'.tr, 'export_failed'.tr, error: true);
                  }
                },
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: Text('app_name'.tr),
                subtitle: Text('about_text'.tr),
              ),
              // اسم المطوّر: سطر صغير هادئ في نهاية الإعدادات
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
                child: Center(
                  child: Text('created_by'.tr, style: TextStyle(fontSize: 12, color: grey, letterSpacing: 0.3)),
                ),
              ),
            ],
          )),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  const _Section(this.title);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: Text(title,
            style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
      );
}
